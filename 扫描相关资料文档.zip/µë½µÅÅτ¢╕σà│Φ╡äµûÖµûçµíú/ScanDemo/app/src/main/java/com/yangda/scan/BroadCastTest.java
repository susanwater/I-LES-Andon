package com.yangda.scan;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.widget.Toast;

/**
 * Created by yangxiaoguang on 2018/6/6.
 */

public class BroadCastTest extends BroadcastReceiver {
    @Override
    public void onReceive(Context context, Intent intent) {

       Log.e("barcode :",intent.getStringExtra("data"));
//
        String ScanResult = intent.getStringExtra("data"); //Read the scan result from the Intent "data"
//
//        Toast.makeText(context,ScanResult,Toast.LENGTH_SHORT).show();
//
//        try{
//            Process p = Runtime.getRuntime().exec("adb shell input text " + ScanResult);
//            p.waitFor();
//            p.destroy();
//        }catch (Exception e)
//        {e.printStackTrace();}
        //---------------------------------------------
        //Modify the scan result as needed.
        //---------------------------------------------
//        Return the Modified scan result string
        Bundle bundle = new Bundle();
        bundle.putString("data", ScanResult);
        Toast.makeText(context,"你扫描了数据",Toast.LENGTH_SHORT).show();
        setResultExtras(bundle);//继续传递
    }
}
