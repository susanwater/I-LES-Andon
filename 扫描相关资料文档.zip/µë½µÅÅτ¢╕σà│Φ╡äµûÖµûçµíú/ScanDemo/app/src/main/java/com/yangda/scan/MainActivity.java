package com.yangda.scan;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.KeyEvent;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Switch;
import android.widget.TextView;

import com.honeywell.aidc.AidcManager;
import com.honeywell.aidc.BarcodeFailureEvent;
import com.honeywell.aidc.BarcodeReadEvent;
import com.honeywell.aidc.BarcodeReader;
import com.honeywell.aidc.TriggerStateChangeEvent;

import java.util.Date;

public class MainActivity extends AppCompatActivity {

    public static final String action = "scan";

    private TextView info;

    //扫描输入框
    private EditText editText;

    //打开和关闭广播 按钮
    private Button regbtn, unregbtn,btnclear;

    //打开和关闭 SDK 模式
    private Button btnopenSDK, btnclostSDK;

    //连续扫描按钮
    private Switch sw1;

    //广播接收类
    private ScanBroadcast scanBroadcast;

    private long times1= 0;
    private long times2 =0;

    /**
     * SDK  管理器
     */
    private AidcManager manager = null;
    //SDK 扫描头阅读器
    private BarcodeReader reader;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        editText = (EditText) findViewById(R.id.code);
        info = (TextView) findViewById(R.id.info);
        btnclear = (Button)findViewById(R.id.btnclear);

        //注册广播按钮
        regbtn = (Button) findViewById(R.id.btnregBroad);
        regbtn.setOnClickListener(onClickListenerRegBroadcast);
        regbtn.setEnabled(true);
        //关闭广播按钮
        unregbtn = (Button) findViewById(R.id.btnunregBroad);
        unregbtn.setOnClickListener(onClickListenerunRegBroadcast);
        unregbtn.setEnabled(false);


        //打开和关闭 SDK  按钮
        btnopenSDK = (Button) findViewById(R.id.btninitsdk);
        btnclostSDK = (Button) findViewById(R.id.btnuninitsdk);
        sw1 = (Switch) findViewById(R.id.sw1);
        btnopenSDK.setOnClickListener(onClickListenerOpenSDK);
        btnclostSDK.setOnClickListener(onClickListenerCloseSDK);

        btnclear.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                editText.setText("");
            }
        });

        btnopenSDK.setEnabled(true);
        btnclostSDK.setEnabled(false);



        editText.setOnKeyListener(new View.OnKeyListener() {
            @Override
            public boolean onKey(View view, int i, KeyEvent keyEvent) {
                return false;
            }
        });
    }

    @Override
    protected void onPause() {
        super.onPause();
        if (reader != null)
            reader.release();
    }

    @Override
    protected void onResume() {
        super.onResume();

        try {
            if (reader != null)
                reader.claim();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    /**
     * 注册广播
     */
    private View.OnClickListener onClickListenerRegBroadcast = new View.OnClickListener() {
        @Override
        public void onClick(View view) {
            scanBroadcast = new ScanBroadcast();
            IntentFilter intentFilter = new IntentFilter(action);
//            intentFilter.addCategory("code");
            //注册广播接收类
            registerReceiver(scanBroadcast, intentFilter);
            regbtn.setEnabled(false);
            unregbtn.setEnabled(true);

        }
    };

    /**
     * 关闭注册广播
     */
    private View.OnClickListener onClickListenerunRegBroadcast = new View.OnClickListener() {
        @Override
        public void onClick(View view) {
            if (scanBroadcast != null) {
                //反注册广播接收类
                unregisterReceiver(scanBroadcast);
                scanBroadcast = null;
                regbtn.setEnabled(true);
                unregbtn.setEnabled(false);
            }
        }
    };


    /**
     * 打开SDK模式
     */
    private View.OnClickListener onClickListenerOpenSDK = new View.OnClickListener() {
        @Override
        public void onClick(View view) {

            //通过SDK接口 创建 SDK 管理器 step 1
            AidcManager.create(MainActivity.this, new AidcManager.CreatedCallback() {
                @Override
                public void onCreated(AidcManager aidcManager) {
                    btnopenSDK.setEnabled(false);
                    btnclostSDK.setEnabled(true);

                    //step 2
                    manager = aidcManager;

                    //step 3
                    reader = manager.createBarcodeReader();
                    String strinfo = "";
                    try {
                        strinfo += "Name:" + reader.getInfo().getName() + "\n";
                        strinfo += "ScannerId:" + reader.getInfo().getScannerId() + "\n";
                        strinfo += "DecodeVersion:" + reader.getInfo().getFullDecodeVersion() + "\n";
                        info.setText(strinfo);


                        // 设置扫描属性
//
//                        reader.setProperty(BarcodeReader.PROPERTY_CODE_93_ENABLED, true);
                        reader.setProperty(BarcodeReader.PROPERTY_QR_CODE_ENABLED, true);
                        reader.setProperty(BarcodeReader.PROPERTY_DATA_PROCESSOR_LAUNCH_BROWSER, false);
//                        reader.setProperty(BarcodeReader.PROPERTY_EAN_13_ENABLED, false);
//                        reader.setProperty(BarcodeReader.PROPERTY_DATAMATRIX_ENABLED, true);
                        // 设置控制类型
                        reader.setProperty(BarcodeReader.PROPERTY_TRIGGER_CONTROL_MODE,
                                BarcodeReader.TRIGGER_CONTROL_MODE_CLIENT_CONTROL);
                        reader.claim();

                        //添加扫描监听 step 4
                        reader.addBarcodeListener(barcodeListener);
                        //监听按扫描键 step 5
                        reader.addTriggerListener(triggerListener);
                    } catch (Exception e) {
                        e.printStackTrace();
                    }


                }
            });
        }
    };


    @Override
    public boolean onKeyUp(int keyCode, KeyEvent event) {


        return super.onKeyUp(keyCode, event);

    }


    /**
     * 关闭SDK
     */
    private View.OnClickListener onClickListenerCloseSDK = new View.OnClickListener() {
        @Override
        public void onClick(View view) {
            if (manager != null) {
                btnopenSDK.setEnabled(true);
                btnclostSDK.setEnabled(false);

                //移除监听
                reader.removeBarcodeListener(barcodeListener);
                reader.removeTriggerListener(triggerListener);

                //关闭扫描器
                reader.release();
//                reader.close();
                reader = null;
                //关闭扫描管理器
//                manager.close();
                manager = null;

            }
        }
    };


    /**
     * 监听扫描键 true 为 按下
     */
    private BarcodeReader.TriggerListener triggerListener = new BarcodeReader.TriggerListener() {
        @Override
        public void onTriggerEvent(TriggerStateChangeEvent triggerStateChangeEvent) {
            Log.i("扫描键状态", String.valueOf(triggerStateChangeEvent.getState()));
            try {
                times1 = (new Date()).getTime();



                //打开红灯
                reader.aim(triggerStateChangeEvent.getState());
                //打开白灯
                reader.light(triggerStateChangeEvent.getState());
                //开始解码
                reader.decode(triggerStateChangeEvent.getState());


            } catch (Exception e) {
                e.printStackTrace();
            }

        }
    };


    /**
     * 扫描监听
     */
    private BarcodeReader.BarcodeListener barcodeListener = new BarcodeReader.BarcodeListener() {
        @Override
        public void onBarcodeEvent(final BarcodeReadEvent barcodeReadEvent) {
            //扫描数据在线程中，如果需要显示在UI 上，必须调用 UI线程来显示
            runOnUiThread(new Runnable() {
                @Override
                public void run() {
                    times2 = (new Date()).getTime();

//                    File file =new File(Environment.getExternalStorageDirectory()+"/" + "log.txt");
//                    FileInputStream fileInputStream=new FileInputStream(file);


                    editText.setText(editText.getText().toString() +"\r\n"+String.valueOf((times2-times1)) + "ms " +
                            barcodeReadEvent.getBarcodeData());
                    Log.i("CodeID:===", barcodeReadEvent.getCodeId());
                    Log.i("AimID:===", barcodeReadEvent.getAimId());
                }
            });

        }

        @Override
        public void onFailureEvent(BarcodeFailureEvent barcodeFailureEvent) {

        }
    };

    /**
     * 定义广播接收类
     */
    public  class ScanBroadcast extends BroadcastReceiver {

        @Override
        public void onReceive(Context context, final Intent intent) {

//            //要显示，需要在UI线程上操作
//            runOnUiThread(new Runnable() {
//                @Override
//                public void run() {
//
//                    //扫描内容 String key data
//                    //显示扫描内容
                    editText.setText(editText.getText().toString()+"\r\n"+
                            intent.getStringExtra("data"));
//                }
//            });


        }
    }
}
