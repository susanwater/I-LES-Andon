package com.yangda.scan;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.os.AsyncTask;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.widget.Toast;

import com.alibaba.fastjson.JSON;
import com.honeywell.aidc.AidcManager;
import com.honeywell.aidc.BarcodeReader;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.URL;
import java.util.HashMap;
import java.util.Map;

public class ScanActivity extends AppCompatActivity {

    //public static String URL = "http://118.89.188.210:8000/zbService/warehousectrl";
    public static String URL = "http://192.168.1.127:8000/zbService/warehousectrl";


    public static final String action = "com.yangda.scan";

    private TextView info;

    //扫描输入框
    private EditText editText;

    //打开和关闭广播 按钮
    private Button btnclear, btn_commit;

    //广播接收类
    private ScanBroadcast scanBroadcast;

    private long times1 = 0;
    private long times2 = 0;

    /**
     * SDK  管理器
     */
    private AidcManager manager = null;

    //SDK 扫描头阅读器
    private BarcodeReader reader;


    private ProgressBar pb_bar;

    String para = null;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_scan);
        editText = (EditText) findViewById(R.id.code);
        info = (TextView) findViewById(R.id.info);
        btnclear = (Button) findViewById(R.id.btnclear);
        btn_commit = (Button) findViewById(R.id.btn_commit);
        btnclear.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                editText.setText("");
            }
        });
        pb_bar = findViewById(R.id.pb_bar);
        pb_bar.setVisibility(View.GONE);
        ScanRegisterReceiver();

        btn_commit.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                if ("".equals(editText.getText().toString().trim())) {
                    Toast.makeText(getBaseContext(), "扫描结果，不能为空", Toast.LENGTH_LONG).show();
                    return;
                }
                if (null == editText.getText().toString()) {
                    Toast.makeText(getBaseContext(), "扫描结果，不能为空", Toast.LENGTH_LONG).show();
                    return;
                }

                pb_bar.setVisibility(View.VISIBLE);
               /*
               二维码的格式：
                {"fixedBin":"01A-A1-L1","partNo":"s854816003","materialStatus":"no"}
                参数分别是：库位，物料号，物料状态。
                */
                MyAsyncTask myAsyncTask = new MyAsyncTask(editText.getText().toString().trim(), new MyAsyncTask.OnResult() {
                    @Override
                    public String result(String result) {
                        pb_bar.setVisibility(View.GONE);
                        if (result != null) {
                            BaseResponseModel mtr = JSON.parseObject(result, BaseResponseModel.class);
                            if (0 == mtr.getCode()) {
                                editText.setText("");
                                Toast.makeText(getBaseContext(), mtr.getMsg(), Toast.LENGTH_LONG).show();
                            } else {
                                Toast.makeText(getBaseContext(), result, Toast.LENGTH_LONG).show();
                            }
                        } else {
                            Toast.makeText(getBaseContext(), " 网络异常，请联系后台服务！！！", Toast.LENGTH_LONG).show();
                        }

                        return null;
                    }
                });
                myAsyncTask.execute();

            }
        });


    }


    @Override
    protected void onDestroy() {
        super.onDestroy();
        ScanCloseReceiver();
    }

    @Override
    protected void onPause() {
        super.onPause();
        if (reader != null)
            reader.release();
    }

    @Override
    protected void onResume() {
        super.onResume();

        try {
            if (reader != null)
                reader.claim();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }


    /**
     * 注册广播
     */
    private void ScanRegisterReceiver() {
        scanBroadcast = new ScanBroadcast();
        IntentFilter intentFilter = new IntentFilter(action);
//            intentFilter.addCategory("code");
        //注册广播接收类
        registerReceiver(scanBroadcast, intentFilter);
    }


    /**
     * 关闭注册广播
     */

    private void ScanCloseReceiver() {
        if (scanBroadcast != null) {
            //反注册广播接收类
            unregisterReceiver(scanBroadcast);
            scanBroadcast = null;
        }
    }


    /**
     * 定义广播接收类
     */
    public class ScanBroadcast extends BroadcastReceiver {

        @Override
        public void onReceive(Context context, final Intent intent) {
            editText.setText(intent.getStringExtra("data"));
            Log.e("---扫描结果：", intent.getStringExtra("data"));
            para = intent.getStringExtra("data");
        }


    }


    public String doPost(String httpUrl, String param) {

        HttpURLConnection connection = null;
        InputStream is = null;
        OutputStream os = null;
        BufferedReader br = null;
        String result = null;
        Log.e("---doPost--param:{}", param);
        try {
            URL url = new URL(httpUrl);
            // 通过远程url连接对象打开连接
            connection = (HttpURLConnection) url.openConnection();
            // 设置连接请求方式
            connection.setRequestMethod("POST");
            // 设置连接主机服务器超时时间：15000毫秒
            connection.setConnectTimeout(15000);
            // 设置读取主机服务器返回数据超时时间：60000毫秒
            connection.setReadTimeout(60000);

            // 默认值为：false，当向远程服务器传送数据/写数据时，需要设置为true
            connection.setDoOutput(true);
            // 默认值为：true，当前向远程服务读取数据时，设置为true，该参数可有可无
            connection.setDoInput(true);
            // 设置传入参数的格式:请求参数应该是 name1=value1&name2=value2 的形式。
            connection.setRequestProperty("Content-Type", "application/json");
            // 设置鉴权信息：Authorization: Bearer da3efcbf-0845-4fe3-8aba-ee040be542c0
            //connection.setRequestProperty("Authorization", "Bearer da3efcbf-0845-4fe3-8aba-ee040be542c0");


            // 通过连接对象获取一个输出流
            os = connection.getOutputStream();
            // 通过输出流对象将参数写出去/传输出去,它是通过字节数组写出的
            os.write(param.getBytes());
            // 通过连接对象获取一个输入流，向远程读取
            if (connection.getResponseCode() == 200) {
                editText.setText("");
                //pb_bar.setVisibility(View.GONE);
                is = connection.getInputStream();
                // 对输入流对象进行包装:charset根据工作项目组的要求来设置
                br = new BufferedReader(new InputStreamReader(is, "UTF-8"));

                StringBuffer sbf = new StringBuffer();
                String temp = null;
                // 循环遍历一行一行读取数据
                while ((temp = br.readLine()) != null) {
                    sbf.append(temp);
                    sbf.append("\r\n");
                }
                result = sbf.toString();
                Log.e("---doPost--result:{}", result);
            }
            Log.e("---doPost:{}", connection.getResponseMessage());
        } catch (MalformedURLException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        } finally {
            // 关闭资源
            if (null != br) {
                try {
                    br.close();
                } catch (IOException e) {
                    e.printStackTrace();
                }
            }
            if (null != os) {
                try {
                    os.close();
                } catch (IOException e) {
                    e.printStackTrace();
                }
            }
            if (null != is) try {
                is.close();
            } catch (IOException e) {
                e.printStackTrace();
            }
            // 断开与远程地址url的连接
            connection.disconnect();

            //pb_bar.setVisibility(View.GONE);
        }
        return result;
    }


}
